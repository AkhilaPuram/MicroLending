import React from "react";
import { useNavigate } from "react-router";
import ReviewInfo from "../RawData";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";


const Reviewer =()=>{
    
const [card,setCard] =useState(ReviewInfo);

const request = { taskState: 'CREATED' };
const [Visible,setVisible] =useState(true);

useEffect(() => {
  
  console.log("inside");
  axios.post('http://localhost:8898/GetAllOpenLoanTasks1', request)
  .then(response => {
    console.log(response.data)
 setCard(response.data);
  });
  

}, []);


const Navigate=useNavigate();
    const removeCard=(id)=>{
   let newInfo =card.filter((ele)=> ele.taskID!==id);
   console.log("inside");
   let uri="http://localhost:8898/CompleteTask/"+id;
   
   axios.patch(uri, request)
   .then(response => {
     console.log(response.data)
  setCard(newInfo);
   })


     setCard(newInfo);
      alert("Data has been succesfully Reviewed")
      if(newInfo.length===0){
        setVisible(false);
       }
       
    }
     const logOut =()=>{
        Navigate("/")
    
   
    }
    return(
      Visible?  
 <div className="mainReview">   
  
{card.map((ele)=>{      
return <div className="Review"><section >
        <h3>LOANS DATA TO BE REVIEWED</h3>

        

        <div className="loanData">Process ID:  {ele.processID}</div>
        <div className="loanData">LOAN TYPE:  {ele.loantype}</div>
        <div className="loanData">AMOUNT: {ele.loanamount}</div>
        <div className="loanData">FIRSTNAME: {ele.firstname}</div>
        <div className="loanData">LASTNAME:  {ele.lastname}</div>
        <div className="loanData">EMAIL: {ele.email}</div>
        <div className="loanData">PHONE NUMBER: {ele.phonenumber}</div>
      </section>
      <button className="loanDatabtn" onClick={()=>removeCard(ele.taskID)}>Complete Review</button>
      </div>
    })
}
<div><button className="logOut" onClick={()=>logOut()}>LogOut</button></div>

</div>:
<div className="mainReview">
<div className="noData">No Data Available to Display</div> 
<div><button className="logOut" onClick={()=>logOut()}>LogOut</button></div>
</div>   
 )

}


 export default Reviewer;
