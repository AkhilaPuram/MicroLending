import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
function User(props) {
    const [initData,finalData]=useState({
        loanType:"",
        amount:0,
        firstName:'',
        LastName:'',
        email:'',
        number:""
    })
    const [ResultData,SetResultData]=useState({
     
      LoanNo:""
  })
   
    const Navigate=useNavigate();
    const takeData=(e)=>{
        e.preventDefault();
 
        const userData = {
     
          firstname:initData.firstName,
          lastname:initData.LastName,
          email: initData.email,
          phonenumber:initData.number,
          loantype:initData.loanType,
          loanamount:initData.amount
        };
        let taskurl="http://localhost:8898/FinishTaskWithPID/";
         axios.post("http://localhost:8898/StartLoan", userData).then((response) => {
          taskurl=taskurl+response.data;
          console.log(response.data);
          /*
            axios.patch(taskurl, userData).then((response) => {
              console.log(response.status, response.data);
              console.log(response.data);
              SetResultData(response.data);
     
         
            });

            */
    
          

          //SetResultData(response.data);
 
     
        }).then(() => 
        {
/*
          axios.patch(taskurl, userData).then((response) => {
            console.log(response.status, response.data);
            console.log(response.data);
            SetResultData(response.data);
   
        }) */});
        

        
        props.sendData(initData);
        Navigate("../Pages/Submission")
    }
   
   
  return (
   
    <div>
      <form onSubmit={takeData}>
        <h3>Loan Application Form</h3>
      
        <div className="UserData">
        <label>Loan Type:</label>{" "}
        <select value={initData.loanType} onChange={(e)=>finalData({...initData,loanType:e.target.value})}>
          <option value="">Loan Type</option>
          <option value="Education Loan">Education Loan</option>
          <option value="Bussiness Loan">Bussiness Loan</option>
          <option value="Improvement">Home Improvement Loan</option>
        </select>
        <br />
        <label>Loan Amount:</label>
        <input type="number" value={initData.amount} onChange={(e)=>finalData({...initData,amount:parseInt(e.target.value)})}/>
        <br />
        <label>First Name:</label>
        <input type="text"value={initData.firstName} onChange={(e)=>finalData({...initData,firstName:e.target.value})}/>
        <br />
        <label>Last Name:</label>
        <input type="text" value={initData.LastName} onChange={(e)=>finalData({...initData,LastName:e.target.value})} />
        <br />
        <label>Email :</label>
        <input type="email" value={initData.email} onChange={(e)=>finalData({...initData,email:e.target.value})} />
        <br />
        <label>Phone number:</label>
        <input type="number" maxLength={10} value={initData.number} onChange={(e)=>finalData({...initData,number:parseInt(e.target.value)})}/>
        <br />
       
       
       </div>
        <button type="submit" className="btn">
          Submit
        </button>
       
      </form>
    </div>
  );
}
export default User;
 