import React from "react";
import { useNavigate } from "react-router";
import ReviewInfo from "../RawData";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

const Manager =()=>{

     
const [card,setCard] =useState(ReviewInfo);
const [Visible,setVisible] =useState(true);
const [decision, setDecision]=useState("");
const request = { status: decision };

useEffect(() => {
  
  console.log("inside");
  axios.post('http://localhost:8898/GetAllOpenLoanTasks2', request)
  .then(response => {
    console.log(response.data)
 setCard(response.data);
  });
  if(card.length===0){
    setVisible(false);
   }
  
   

}, []);

const getDecision=(event ) =>
{
  
  let result=event.target.value;

  
  setDecision( prev =>{
 
  return result;
});  
} 

console.log("decision "+decision);

const Navigate=useNavigate();
    const removeCard=(id)=>{
   let newInfo =card.filter((ele)=> ele.taskID!==id);
   console.log("inside");
   console.log()
   let uri="http://localhost:8898/CompleteTask/"+id;
   
   axios.patch(uri, request)
   .then(response => {
     console.log(response.data)
  setCard(newInfo);
   })


     setCard(newInfo);
      alert("Approval process is completed");
      if(newInfo.length===0){
        setVisible(false);
       }
       
    }
     const logOut =()=>{
        Navigate("/")
    
   
    }
    return(
      Visible?  
 <div className="mainReview">
   
{card.map((ele)=>{      
return <div className="Approve"><section >
        <h3>LOANS DATA TO BE APPROVED</h3>
        <div className="loanData">Process ID:  {ele.processID}</div>
        <div className="loanData">LOAN TYPE:  {ele.loantype}</div>
        <div className="loanData">AMOUNT: {ele.loanamount}</div>
        <div className="loanData">FIRSTNAME: {ele.firstname}</div>
        <div className="loanData">LASTNAME:  {ele.lastname}</div>
        <div className="loanData">EMAIL: {ele.email}</div>
        <div className="loanData">PHONE NUMBER: {ele.phonenumber}</div>
      </section>
      <div className="decision">
        <div>
      <input type="radio" value="Approve"  id="approve" name="action"  onClick={getDecision} checked={decision=== "Approve"}/><label className="radiolable" htmlFor="approve">Approve</label></div>
      <div><input type="radio" value="Reject" id="reject" name="action" onClick={getDecision} checked={decision=== "Reject"}/><label className="radiolable" htmlFor="reject">Reject</label></div>
          </div>   
          <div>
      <button className="loanDatabtn" onClick={()=>removeCard(ele.taskID)}>Complete Approval</button>
      </div>
      </div>
    })
}
<div><button className="logOut" onClick={()=>logOut()}>LogOut</button></div>

</div>  : 
<div className="mainReview">
<div className="noData">No Data Available to Display</div> 
<div><button className="logOut" onClick={()=>logOut()}>LogOut</button></div>
</div>   

    )

}

export default Manager;