import React from "react";

function Submission(){
    return(
        <h1>Your Data has been Succesfully submitted</h1>
    )
}
export default Submission;
