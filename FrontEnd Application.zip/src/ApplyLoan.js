import React from "react";

function ApplyLoan() {
 
    // const openInNewTab = (url) => {
    //     window.open(url, '_blank', 'noreferrer');
    //   }
  ;
  return (
    <div class="applyLoan">
      <img src="aaseya_it_services_pvt_ltd_logo (1).jpg" alt=""></img>
      <div class="Loan">
        <div>Aaseya</div>
        {/* <button role="link" onClick={()=>openInNewTab("https://jfk-1.tasklist.camunda.io/348b75d6-605b-4729-b411-4bdb12131a69")}>Apply for Loan</button> */}
      </div>
    </div>
  );
}

export default ApplyLoan;
