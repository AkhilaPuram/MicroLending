import React from "react";
import { useState } from "react";

import { useNavigate } from "react-router-dom";

function Login(props) {
  const [type, setType] = useState("");
  const [Name, setName] = useState("");
  const [Password, setPassword] = useState("");
  const Navigate = useNavigate();

  const handleChange = (e) => {
    setType(e.target.value);
  };
  const authenticate = (UserName, UserPassword, type) => {
    if (UserName === "admin" && UserPassword === "ADMIN") {
      props.status(false);
      type === "User"
        ? Navigate("./Pages/User")
        : type === "Reviewer"
        ? Navigate("./Pages/Reviewer")
        : Navigate("./Pages/Manager");
    }
  };

  const checkData = (e) => {
    e.preventDefault();
    authenticate(Name, Password, type);

    console.log("submitted");
  };
  return (
    <form onSubmit={checkData} className="form">
      <div className="UserData">
      <label for="username">
        UserName:{" "}
        
      </label><input type="text" id="username"
          value={Name}
          onChange={(e) => {
            setName(e.target.value);
          }}
        />

      <br />
      <label for="pass">
        Password:{" "}
        
      </label><input
          type="password"
          value={Password} id="pass"
          onChange={(e) => {
            setPassword(e.target.value);
          }}
        />
      <br />
      <label for="selection">User Type:{" "}
        
      </label><select value={type} onChange={handleChange} id="selection" >
          <option value="">Choose one</option>
          <option value="User">User</option>
          <option value="Reviewer">Reviewer</option>
          <option value="manager">Manager</option>
        </select>
      <br />
      <button type="submit" className="btn">
        Login
      </button>
      </div>
    </form>
  );
}

export default Login;
