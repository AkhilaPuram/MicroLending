import React from "react";
import "./App.css";

import Login from "./Login";
import { Routes, Route } from "react-router-dom";
import User from "./Pages/User";
import Manager from "./Pages/Manager";
import Reviewer from "./Pages/Reviewer";
import { useState } from "react";
import Submission from "./Pages/Submission";
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const[passData,setPassData]=useState("");
  const[dataToManager,setDatatoManager]=useState("")
  const statusChange = (val) => {
    setIsLoggedIn(val);
  };
  const getData=(val)=>{
setPassData(val);
  }
  const dataSent =(Details)=>{
setDatatoManager(Details);
  }
  return (
    <div>
      
      {
       
      isLoggedIn ? (
        
        <Login status={statusChange}/>
       
      ) : (
          <Routes>
          <Route path="/" element={<Login status={statusChange}/>} />
          <Route path="Pages/User" element={<User sendData={getData}/>} />
          <Route path="Pages/Manager" element={<Manager receiveData={dataToManager}/>} />
          <Route path="Pages/Reviewer" element={<Reviewer Data={passData} sendtoManager ={dataSent} />} />
          <Route path="Pages/Submission" element={<Submission/>} />
          </Routes>
      )}
      
    </div>
  );
}


export default App;
