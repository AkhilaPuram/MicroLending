const ReviewInfo = [
  {
    id: 1,
    loantype: "",
    loanamount: 0,
    firstname: "",
    lastname: "",
    phonenumber: 0,
    email:"",
    processID:"",
    taskID:""
  },
  
];

export default ReviewInfo;
